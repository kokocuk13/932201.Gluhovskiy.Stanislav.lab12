﻿namespace lab12.Interfaces
{
    public interface ICalculateService
    {
        int calculate(int firstValue, int secondValue, string selectedMathSign);
    }
}
