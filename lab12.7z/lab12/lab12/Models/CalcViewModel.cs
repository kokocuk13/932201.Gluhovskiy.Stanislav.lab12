﻿namespace lab12.Models
{
    public class CalcViewModel
    {
        public string CalcName;
        public string ProcessContorollerName;
        public int FirstValue;
        public int SecondValue;
        public string MathOperationName;
    }
}
